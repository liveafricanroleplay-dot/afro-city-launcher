# AFRO CITY RP Launcher — Android source

This is a branding-customized working copy of the supplied Alyn SA-MP Mobile v17.x source snapshot.

## AFRO CITY RP changes
- App display name: AFRO CITY RP Launcher
- App icon and in-app launcher logo: supplied AFRO CITY RP artwork
- Discord destination: https://discord.gg/EdNWteUjWG
- GitHub destination: https://github.com/liveafricanroleplay-dot/AFRO-CITY-RP
- Visible copyright label: AFRO CITY RP

## Compatibility preserved
The original Java package/namespace and native C++ SA-MP client structure are retained to avoid breaking Java/JNI integration. The source README identifies the native client as requiring GTA: San Andreas Android 2.10.

## Important backend note
The original Alyn-hosted update, server-list, FAQ, changelog and preview JSON endpoints remain unchanged. They are operational dependencies in this source; replacing them requires AFRO CITY RP-hosted compatible endpoint files and schemas. The Website shortcut now opens the AFRO CITY RP Discord invitation.

## Build requirements
- Android Studio
- JDK 17
- Android SDK 35
- NDK 25.1.8937393
- CMake

The included signing keystore and Google Services configuration were removed from this working copy. Debug builds use Android's standard debug signing. A release APK needs a new private signing key managed outside the repository.

## Source provenance
Based on the supplied Alyn SA-MP Mobile v17.x source archive. The archive did not contain a top-level LICENSE file. Verify third-party component and asset permissions before public redistribution. Do not redistribute proprietary GTA assets without the relevant rights.
